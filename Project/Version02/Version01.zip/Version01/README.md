Sample file for creating folder structure

Initial version of the project should go here.
